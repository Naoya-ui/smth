/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.nhatro.dao;

import java.util.List;

/**
 *
 * @author user
 * @param <T>
 * @param <ID>
 */
public interface Crud_DAO<T, ID> {  

    T create(T entity);

    void update(T entity);

    void deleteById(ID id);

    List<T> findAll();

    T findById(ID id);
}
