/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.nhatro.dao;

import java.util.List;
import poly.nhatro.entity.BookingRequest;
import poly.nhatro.entity.Favorite;
import poly.nhatro.entity.Message;
import poly.nhatro.entity.Room;
import poly.nhatro.entity.RoomImage;
import poly.nhatro.entity.RoomVideo;
import poly.nhatro.entity.User;

/**
 *
 * @author user
 */
public class Specific_DAO {

    public interface FavoriteDAO extends Crud_DAO<Favorite, String> {

    }

    public interface BookingRequestDAO extends Crud_DAO<BookingRequest, String> {

        
    }

    public interface UserDAO extends Crud_DAO<User, String> {

    }

    public interface RoomDAO extends Crud_DAO<Room, Integer> {
        
    }

    public interface RoomImageDAO extends Crud_DAO<RoomImage, Integer> {

    }

    public interface MessageDAO extends Crud_DAO<Message, Integer> {

   
    }
    public interface RoomVideoDAO extends Crud_DAO<RoomVideo, Integer> {

    }

}
