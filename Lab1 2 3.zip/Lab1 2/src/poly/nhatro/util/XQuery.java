package poly.nhatro.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import poly.nhatro.entity.User;

public class XQuery {

    public static <B> B getSingleBean(Class<B> beanClass, String sql, Object... values) {
        List<B> list = XQuery.getBeanList(beanClass, sql, values);
        if (!list.isEmpty()) {
            return list.get(0);
        }
        return null;
    }

    public static <B> List<B> getBeanList(Class<B> beanClass, String sql, Object... values) {
        List<B> list = new ArrayList<>();
        try (ResultSet rs = XJdbc.executeQuery(sql, values)) {
            while (rs.next()) {
                list.add(XQuery.readBean(rs, beanClass));
            }
        } catch (Exception ex) {
            throw new RuntimeException("Lỗi truy vấn: " + ex.getMessage(), ex);
        }
        return list;
    }

    private static <B> B readBean(ResultSet resultSet, Class<B> beanClass) throws Exception {
    B bean = beanClass.getDeclaredConstructor().newInstance();
    Method[] methods = beanClass.getDeclaredMethods();

    for (Method method : methods) {
        String name = method.getName();
        if (name.startsWith("set") && method.getParameterCount() == 1) {
            String columnName = name.substring(3);
            try {
                Object value = null;
                try {
                    // Lấy đúng tên cột
                    value = resultSet.getObject(columnName);
                } catch (SQLException e1) {
                    try {
                        // Thử chữ thường
                        value = resultSet.getObject(columnName.toLowerCase());
                    } catch (SQLException e2) {
                        System.out.printf("⚠ Column '%s' not found in result set!\n", columnName);
                        continue; // Bỏ qua nếu cột không tồn tại
                    }
                }

                if (value != null) {
                    // ÉP KIỂU DỮ LIỆU
                    Class<?> paramType = method.getParameterTypes()[0];

                    if (paramType == int.class || paramType == Integer.class) {
                        value = ((Number) value).intValue();
                    } else if (paramType == float.class || paramType == Float.class) {
                        value = ((Number) value).floatValue();
                    } else if (paramType == double.class || paramType == Double.class) {
                        value = ((Number) value).doubleValue();
                    } else if (paramType == boolean.class || paramType == Boolean.class) {
                        if (value instanceof Number) {
                            value = ((Number) value).intValue() != 0;
                        } else {
                            value = Boolean.parseBoolean(value.toString());
                        }
                    } else if (paramType == java.util.Date.class && value instanceof java.sql.Timestamp) {
                        value = new java.util.Date(((java.sql.Timestamp) value).getTime());
                    }
                }

                method.invoke(bean, value);

            } catch (IllegalAccessException | InvocationTargetException e) {
                System.out.printf("⚠ Failed to set property '%s': %s\n", columnName, e.getMessage());
            }
        }
    }

    return bean;
}


    // --- Demo/Test usage ---
    public static void main(String[] args) {
        demo1();
        demo2();
    }

    private static void demo1() {
        String sql = "SELECT * FROM Users WHERE Username=? AND Password=?";
        User user = XQuery.getSingleBean(User.class, sql, "NghiemN", "123456");
        System.out.println("User: " + user);
    }

    private static void demo2() {
        String sql = "SELECT * FROM Users WHERE Fullname LIKE ?";
        List<User> list = XQuery.getBeanList(User.class, sql, "%Nguyễn%");
        System.out.println("Found: " + list.size() + " users");
        for (User u : list) {
            System.out.println(u);
        }
    }
}
