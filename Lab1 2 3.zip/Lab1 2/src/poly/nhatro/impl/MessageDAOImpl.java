/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.nhatro.impl;

import java.util.List;
import poly.nhatro.dao.Specific_DAO.MessageDAO;
import poly.nhatro.entity.Message;
import poly.nhatro.util.XJdbc;
import poly.nhatro.util.XQuery;

/**
 *
 * @author user
 */
public class MessageDAOImpl implements MessageDAO {

    String createSql
            = "INSERT INTO Message (MessageID, UserID, RoomID, Credit, Content, Timestamp) VALUES (?, ?, ?, ?, ?, ?)";

    String findAllSql = "SELECT * FROM Message";

    String findByIdSql = "SELECT * FROM Message WHERE MessageID = ?";

    String updateSql
            = "UPDATE Message SET UserID = ?, RoomID = ?, Credit = ?, Content = ?, Timestamp = ? WHERE MessageID = ?";

    String deleteSql = "DELETE FROM Message WHERE MessageID = ?";

    @Override
    public Message create(Message entity) {
        Object[] values = {
            entity.getMessageID(),
            entity.getUserID(),
            entity.getRoomID(),
            entity.getCredit(),
            entity.getContent(),
            entity.getTimestamp()};
        XJdbc.executeUpdate(createSql, values);
        return entity;
    }

    @Override
    public void update(Message entity) {
        Object[] values = {
            entity.getUserID(),
            entity.getRoomID(),
            entity.getCredit(),
            entity.getContent(),
            entity.getTimestamp(),
            entity.getUserID()
        };
        XJdbc.executeUpdate(updateSql, values);
    }
    @Override
    public List<Message> findAll() {
        return XQuery.getBeanList(Message.class, findAllSql);
    }

    @Override
    public void deleteById(Integer id) {
        XJdbc.executeUpdate(deleteSql, id);
    }

    @Override
    public Message findById(Integer id) {
       return XQuery.getSingleBean(Message.class, findByIdSql, id);
    }

}
