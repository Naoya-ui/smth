/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.nhatro.impl;

import java.util.List;
import poly.nhatro.dao.Specific_DAO.BookingRequestDAO;
import poly.nhatro.entity.BookingRequest;
import poly.nhatro.util.XJdbc;
import poly.nhatro.util.XQuery;

/**
 *
 * @author user
 */
public class BookingRequestDAOImpl implements BookingRequestDAO {
    String createSql = 
    "INSERT INTO BookingRequest (RequestID, UserID, RoomID, Status, Request_Date) VALUES (?, ?, ?, ?, ?)";

String findAllSql = "SELECT * FROM BookingRequest";

String findByIdSql = "SELECT * FROM BookingRequest WHERE RequestID = ?";

String updateSql = 
    "UPDATE BookingRequest SET UserID = ?, RoomID = ?, Status = ?, Request_Date = ? WHERE RequestID = ?";

String deleteSql = "DELETE FROM BookingRequest WHERE RequestID = ?";

    @Override
    public BookingRequest create(BookingRequest entity) {
       Object[] values = {
            entity.getRequestID(),
           entity.getUserID(),
           entity.getRoomID(),
           entity.getStatus(),
           entity.getRequestDate()
            };
        XJdbc.executeUpdate(createSql, values);
        return entity;
    }

    @Override
    public void update(BookingRequest entity) {
         Object[] values = {
           entity.getUserID(),
           entity.getRoomID(),
           entity.getStatus(),
           entity.getRequestDate(),
           entity.getRequestID()
            };
        XJdbc.executeUpdate(updateSql, values);
    }

    @Override
    public void deleteById(String id) {
        XJdbc.executeUpdate(deleteSql, id);
    }

    @Override
    public List<BookingRequest> findAll() {
          return XQuery.getBeanList(BookingRequest.class, findAllSql);
    }

    @Override
    public BookingRequest findById(String id) {
       return XQuery.getSingleBean(BookingRequest.class, findByIdSql, id);
    }

    
}
