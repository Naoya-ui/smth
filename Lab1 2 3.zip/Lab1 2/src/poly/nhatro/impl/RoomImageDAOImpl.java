/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.nhatro.impl;

import java.util.List;
import poly.nhatro.dao.Specific_DAO.RoomImageDAO;
import poly.nhatro.entity.RoomImage;

import poly.nhatro.util.XJdbc;
import poly.nhatro.util.XQuery;

/**
 *
 * @author user
 */
public class RoomImageDAOImpl implements RoomImageDAO {

    String createSql = "INSERT INTO RoomImage (ImageID, RoomID, Image_URL) VALUES (?, ?, ?)";

    String findAllSql = "SELECT * FROM RoomImage";

    String findByIdSql = "SELECT * FROM RoomImage WHERE ImageID = ?";

    String updateSql = "UPDATE RoomImage SET RoomID = ?, Image_URL = ? WHERE ImageID = ?";

    String deleteSql = "DELETE FROM RoomImage WHERE ImageID = ?";

    @Override
    public RoomImage create(RoomImage entity) {
        Object[] values = {
            entity.getImageID(),
            entity.getRoomID(),
            entity.getImageURL()
        };
        XJdbc.executeUpdate(createSql, values);
        return entity;
    }

    @Override
    public void update(RoomImage entity) {
        Object[] values = {
            entity.getRoomID(),
            entity.getImageURL(),
            entity.getRoomID()
        };
        XJdbc.executeUpdate(updateSql, values);
    }

    @Override
    public List<RoomImage> findAll() {
        return XQuery.getBeanList(RoomImage.class, findAllSql);
    }
    @Override
    public void deleteById(Integer id) {
        XJdbc.executeUpdate(deleteSql, id);
    }

    @Override
    public RoomImage findById(Integer id) {
        return XQuery.getSingleBean(RoomImage.class, findByIdSql, id);
    }

}
