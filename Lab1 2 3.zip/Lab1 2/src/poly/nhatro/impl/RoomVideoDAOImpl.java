/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.nhatro.impl;

import java.util.List;
import poly.nhatro.dao.Specific_DAO.RoomVideoDAO;
import poly.nhatro.entity.RoomVideo;
import poly.nhatro.util.XJdbc;
import poly.nhatro.util.XQuery;

/**
 *
 * @author user
 */
public class RoomVideoDAOImpl implements RoomVideoDAO {

    String createSql
            = "INSERT INTO RoomVideo (VideoID, RoomID, Video_URL) VALUES (?, ?, ?)";

    String findAllSql = "SELECT * FROM RoomVideo";

    String findByIdSql = "SELECT * FROM RoomVideo WHERE VideoID = ?";

    String updateSql
            = "UPDATE RoomVideo SET RoomID = ?, Video_URL = ? WHERE VideoID = ?";

    String deleteSql = "DELETE FROM RoomVideo WHERE VideoID = ?";

    @Override
    public RoomVideo create(RoomVideo entity) {
        Object[] values = {
            entity.getVideoID(),    
            entity.getRoomID(),
            entity.getVideoURL()
        };
        XJdbc.executeUpdate(createSql, values);
        return entity;
    }

    @Override
    public void update(RoomVideo entity) {
        Object[] values = {
            entity.getRoomID(),
            entity.getVideoURL(),
            entity.getVideoID()
        };
        XJdbc.executeUpdate(updateSql, values);
    }

    @Override
    public List<RoomVideo> findAll() {
        return XQuery.getBeanList(RoomVideo.class, findAllSql);
    }


    @Override
    public void deleteById(Integer id) {
         XJdbc.executeUpdate(deleteSql, id);
    }

    @Override
    public RoomVideo findById(Integer id) {
        return XQuery.getSingleBean(RoomVideo.class, findByIdSql, id);
    }

}
