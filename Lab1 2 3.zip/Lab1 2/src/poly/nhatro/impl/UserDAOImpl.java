/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.nhatro.impl;

import java.util.List;
import poly.nhatro.dao.Specific_DAO.UserDAO;
import poly.nhatro.entity.User;
import poly.nhatro.util.XJdbc;
import poly.nhatro.util.XQuery;

/**
 *
 * @author user
 */
public class UserDAOImpl implements UserDAO {

    // INSERT
    String createSql = "INSERT INTO [User] (UserID, Username, Password, PhoneNumber, Email, Role) VALUES (?, ?, ?, ?, ?, ?)";

// SELECT ALL
    String findAllSql = "SELECT * FROM [User]";

// SELECT BY ID
    String findByIdSql = "SELECT * FROM [User] WHERE UserID = ?";

// UPDATE
    String updateSql = "UPDATE [User] SET Username = ?, Password = ?, PhoneNumber = ?, Email = ?, Role = ? WHERE UserID = ?";

// DELETE
    String deleteSql = "DELETE FROM [User] WHERE UserID = ?";

    @Override
    public User create(User entity) {
        Object[] values = {
            entity.getUserID(),
            entity.getUsername(),
            entity.getPhoneNumber(),
            entity.getEmail(),
            entity.getRole()
        };
        XJdbc.executeUpdate(createSql, values);
        return entity;
    }

    @Override
    public void update(User entity) {
        Object[] values = {
            entity.getUsername(),
            entity.getPassword(),
            entity.getPhoneNumber(),
            entity.getEmail(),
            entity.getRole(),
            entity.getUserID()
        };
        XJdbc.executeUpdate(updateSql, values);
    }

    @Override
    public void deleteById(String id) {
        XJdbc.executeUpdate(deleteSql, id);
    }

    @Override
    public List<User> findAll() {
        return XQuery.getBeanList(User.class, findAllSql);
    }

    @Override
    public User findById(String id) {
        return XQuery.getSingleBean(User.class, findByIdSql, id);
    }

}
