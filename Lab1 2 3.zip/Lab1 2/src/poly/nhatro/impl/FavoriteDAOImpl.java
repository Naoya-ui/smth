/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.nhatro.impl;

import java.util.List;
import poly.nhatro.dao.Specific_DAO.FavoriteDAO;
import poly.nhatro.entity.Favorite;
import poly.nhatro.util.XJdbc;
import poly.nhatro.util.XQuery;

/**
 *
 * @author user
 */
public class FavoriteDAOImpl implements FavoriteDAO {

    String createSql
            = "INSERT INTO Favorite (FavoriteID, UserID, RoomID, Date_Added) VALUES (?, ?, ?, ?)";

    String findAllSql = "SELECT * FROM Favorite";

    String findByIdSql = "SELECT * FROM Favorite WHERE FavoriteID = ?";

    String updateSql
            = "UPDATE Favorite SET UserID = ?, RoomID = ?, Date_Added = ? WHERE FavoriteID = ?";

    String deleteSql = "DELETE FROM Favorite WHERE FavoriteID = ?";

    @Override
    public Favorite create(Favorite entity) {
        Object[] values = {
            entity.getFavoriteID(),
            entity.getUserID(),
            entity.getRoomID(),
            entity.getDateAdded()
        };
        XJdbc.executeUpdate(createSql, values);
        return entity;
    }

    @Override
    public void update(Favorite entity) {
        Object[] values = {
            entity.getUserID(),
            entity.getUserID(),
            entity.getRoomID(),
            entity.getDateAdded()
        };
        XJdbc.executeUpdate(updateSql, values);
    }


    @Override
    public List<Favorite> findAll() {
        return XQuery.getBeanList(Favorite.class, findAllSql);
    }

    @Override
    public void deleteById(String id) {
       XJdbc.executeUpdate(deleteSql, id);
    }

    @Override
    public Favorite findById(String id) {
         return XQuery.getSingleBean(Favorite.class, findByIdSql, id);
    }
}
