/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.nhatro.impl;

import java.util.List;
import poly.nhatro.dao.Specific_DAO.RoomDAO;
import poly.nhatro.entity.Room;
import poly.nhatro.util.XJdbc;
import poly.nhatro.util.XQuery;

/**
 *
 * @author user
 */
public class RoomDAOImpl implements RoomDAO {
    // INSERT

    String createSql = "INSERT INTO Room (RoomID, UserID, Title, Description, Area, Location, Price, Date_Posted, Is_Available) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
// SELECT ALL
    String findAllSql= "SELECT * FROM Room";
// SELECT BY ID
    String findByIdSql = "SELECT * FROM Room WHERE RoomID = ?";

// UPDATE
    String updateSql = "UPDATE Room SET UserID = ?, Title = ?, Description = ?, Area = ?, Location = ?, Price = ?, Date_Posted = ?, Is_Available = ? WHERE RoomID = ?";

// DELETE
    String deleteSql = "DELETE FROM Room WHERE RoomID = ?";

    @Override
    public Room create(Room entity) {
        Object[] values = {
            entity.getRoomID(),
            entity.getUserID(), 
            entity.getTitle(),
            entity.getDescription(),
            entity.getArea(),
            entity.getLocation(),
            entity.getPrice(),
            entity.getDate_posted(),
            entity.getIsAvailble()
        };
        XJdbc.executeUpdate(createSql, values);
        return entity;
    }

    @Override
    public void update(Room entity) {
        Object[] values = {           
            entity.getUserID(),
            entity.getTitle(),
            entity.getDescription(),
            entity.getArea(),
            entity.getLocation(),
            entity.getPrice(),
            entity.getDate_posted(),
            entity.getIsAvailble(),
            entity.getRoomID()
        };     
        XJdbc.executeUpdate(updateSql, values);
    }
    @Override
    public List<Room> findAll() {
        return XQuery.getBeanList(Room.class, findAllSql);
    }

    @Override
    public void deleteById(Integer id) {
       XJdbc.executeUpdate(deleteSql, id);
    }

    @Override
    public Room findById(Integer id) {
        return XQuery.getSingleBean(Room.class, findByIdSql, id);
    }
}
