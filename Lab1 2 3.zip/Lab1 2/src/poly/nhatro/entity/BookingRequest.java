/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.nhatro.entity;

import java.util.Date;

/**
 *
 * @author user
 */

public class BookingRequest {
    private int requestID;
    private int userID;
    private int roomID;
    private String status;
    private Date requestDate;

    public BookingRequest() {}

    public BookingRequest(int requestID, int userID, int roomID, String status, Date requestDate) {
        this.requestID = requestID;
        this.userID = userID;
        this.roomID = roomID;
        this.status = status;
        this.requestDate = requestDate;
    }

    public int getRequestID() { return requestID; }
    public void setRequestID(int requestID) { this.requestID = requestID; }

    public int getUserID() { return userID; }
    public void setUserID(int userID) { this.userID = userID; }

    public int getRoomID() { return roomID; }
    public void setRoomID(int roomID) { this.roomID = roomID; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Date getRequestDate() { return requestDate; }
    public void setRequestDate(Date requestDate) { this.requestDate = requestDate; }

}
