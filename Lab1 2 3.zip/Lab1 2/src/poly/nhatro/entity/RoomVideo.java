/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.nhatro.entity;

/**
 *
 * @author user
 */

public class RoomVideo {
    private int videoID;
    private int roomID;
    private String videoURL;

    public RoomVideo() {}

    public RoomVideo(int videoID, int roomID, String videoURL) {
        this.videoID = videoID;
        this.roomID = roomID;
        this.videoURL = videoURL;
    }

    public int getVideoID() { return videoID; }
    public void setVideoID(int videoID) { this.videoID = videoID; }

    public int getRoomID() { return roomID; }
    public void setRoomID(int roomID) { this.roomID = roomID; }

    public String getVideoURL() { return videoURL; }
    public void setVideoURL(String videoURL) { this.videoURL = videoURL; }
}