/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.nhatro.entity;

import java.util.Date;

/**
 *
 * @author user
 */
public class Room {

    public int RoomID;
    public int UserID;
    public String Title;
    public String Description;
    public float Area;
    public String Location;
    public Double price;
    public Date Date_posted;
    public int IsAvailble;

    public Room() {
    }

    
    public Room(int RoomID, int UserID, String Title, String Description, float Area, String Location, Double price, Date Date_posted, int IsAvailble) {
        this.RoomID = RoomID;
        this.UserID = UserID;
        this.Title = Title;
        this.Description = Description;
        this.Area = Area;
        this.Location = Location;
        this.price = price;
        this.Date_posted = Date_posted;
        this.IsAvailble = IsAvailble;
    }

    public int getRoomID() {
        return RoomID;
    }

    public void setRoomID(int RoomID) {
        this.RoomID = RoomID;
    }

    public int getUserID() {
        return UserID;
    }

    public void setUserID(int UserID) {
        this.UserID = UserID;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String Title) {
        this.Title = Title;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public float getArea() {
        return Area;
    }

    public void setArea(float Area) {
        this.Area = Area;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String Location) {
        this.Location = Location;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Date getDate_posted() {
        return Date_posted;
    }

    public void setDate_posted(Date Date_posted) {
        this.Date_posted = Date_posted;
    }

    public int getIsAvailble() {
        return IsAvailble;
    }

    public void setIsAvailble(int Is_Availble) {
        this.IsAvailble = IsAvailble;
    }
    
    
}
