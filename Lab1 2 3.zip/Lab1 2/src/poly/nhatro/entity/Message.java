/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.nhatro.entity;

import java.util.Date;
import jdk.jfr.Timestamp;

/**
 *
 * @author user
 */
public class Message {

    private int messageID;
    private int userID;
    private int roomID;
    private String credit;
    private String content;
    private Timestamp timestamp;

    public Message() {
    }

    public Message(int messageID, int userID, int roomID, String credit, String content, Timestamp timestamp) {
        this.messageID = messageID;
        this.userID = userID;
        this.roomID = roomID;
        this.credit = credit;
        this.content = content;
        this.timestamp = timestamp;
    }

    public int getMessageID() {
        return messageID;
    }

    public void setMessageID(int messageID) {
        this.messageID = messageID;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public int getRoomID() {
        return roomID;
    }

    public void setRoomID(int roomID) {
        this.roomID = roomID;
    }

    public String getCredit() {
        return credit;
    }

    public void setCredit(String credit) {
        this.credit = credit;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

}
