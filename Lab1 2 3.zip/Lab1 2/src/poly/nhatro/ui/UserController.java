/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poly.nhatro.ui;
import poly.nhatro.dao.CrudController;
import poly.nhatro.entity.User;
/**
 *
 * @author user
 */
public interface UserController  extends CrudController<User>{
    
}
